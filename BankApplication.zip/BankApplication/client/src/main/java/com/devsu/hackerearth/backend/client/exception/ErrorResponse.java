package com.devsu.hackerearth.backend.client.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
public class ErrorResponse {
    private HttpStatus status;
    private String message;
    private LocalDateTime timesDateTime = LocalDateTime.now();
}
