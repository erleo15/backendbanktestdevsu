package com.devsu.hackerearth.backend.client.model;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.devsu.hackerearth.backend.client.model.dto.ClientDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@EqualsAndHashCode(callSuper=false)
@Table(name = "client", uniqueConstraints = @UniqueConstraint(name = "UK_client_dni_isActive",
	columnNames = { "dni", "isActive" }))
public class Client extends Person {
	private String password;
	private boolean isActive;

	public Client(ClientDto clientDto) {
		this.isActive = clientDto.isActive();
		this.password = clientDto.getPassword();
		setAddress(clientDto.getAddress());
		setAge(clientDto.getAge());
		setDni(clientDto.getDni());
		setGender(clientDto.getGender());
		setId(clientDto.getId());
		setName(clientDto.getName());
		setPhone(clientDto.getPhone());
	}
}
