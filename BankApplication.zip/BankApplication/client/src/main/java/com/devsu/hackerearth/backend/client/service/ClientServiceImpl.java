package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.client.exception.ClientNotFoundException;
import com.devsu.hackerearth.backend.client.exception.DuplicatedDniException;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients
		List<Client> clientsResult = clientRepository.findByIsActiveTrue();
		return clientsResult.stream().map(ClientDto::new).collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		Client clientResult = clientRepository.findByIdAndIsActiveTrue(id)
				.orElseThrow(() -> new ClientNotFoundException(id));
		ClientDto clientDto = new ClientDto(clientResult.getId(), clientResult.getDni(),
				clientResult.getName(), clientResult.getPassword(), clientResult.getGender(), clientResult.getAge(),
				clientResult.getAddress(), clientResult.getPhone(), clientResult.isActive());
		return clientDto;
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		// Create client
		Client client = new Client(clientDto.getPassword(), clientDto.isActive());
		client.setAddress(clientDto.getAddress());
		client.setAge(clientDto.getAge());
		client.setDni(clientDto.getDni());
		client.setGender(clientDto.getGender());
		client.setName(clientDto.getName());
		client.setPhone(clientDto.getPhone());

		Client newClient = clientRepository.save(client);
		return new ClientDto(newClient.getId(), newClient.getDni(), newClient.getName(), newClient.getPassword(),
				newClient.getGender(), newClient.getAge(),
				newClient.getAddress(), newClient.getPhone(), newClient.isActive());
	}

	@Transactional
	@Override
	public ClientDto update(ClientDto clientDto) {
		// Update client
		Client resultFind = clientRepository.findByIdAndIsActiveTrue(clientDto.getId()).orElseThrow(
				() -> new ClientNotFoundException(clientDto.getId()));
		if (resultFind.getDni().compareTo(clientDto.getDni()) != 0 &&
				clientRepository.existsByDniAndIsActiveTrue(clientDto.getDni())) {
			throw new DuplicatedDniException(clientDto.getDni());
		}
		resultFind.setDni(clientDto.getDni());
		resultFind.setName(clientDto.getName());
		resultFind.setPassword(clientDto.getPassword());
		resultFind.setGender(clientDto.getGender());
		resultFind.setAge(clientDto.getAge());
		resultFind.setAddress(clientDto.getAddress());
		resultFind.setPhone(clientDto.getPhone());
		resultFind.setActive(clientDto.isActive());
		Client cliente = clientRepository.save(resultFind);
		ClientDto clientDtoUpdated = new ClientDto(cliente);
		return clientDtoUpdated;
	}

	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		// Partial update account
		ClientDto resultClientDto = new ClientDto(
				clientRepository.findById(id).orElseThrow(() -> new ClientNotFoundException(id)))
				.setActive(partialClientDto.isActive());
		Client clientSaved = clientRepository.save(new Client(resultClientDto));
		ClientDto clientDtoUpdated = new ClientDto(clientSaved);
		return clientDtoUpdated;
	}

	@Override
	public void deleteById(Long id) {
		// Delete client
		Client client = clientRepository.findById(id).orElseThrow(
				() -> new ClientNotFoundException(id));
		client.setActive(false);
		clientRepository.save(client);
	}
}
