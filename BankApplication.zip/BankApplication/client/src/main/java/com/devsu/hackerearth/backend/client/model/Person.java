package com.devsu.hackerearth.backend.client.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import lombok.Data;
import lombok.EqualsAndHashCode;

@MappedSuperclass
@Data
@EqualsAndHashCode(callSuper=false)
public class Person extends Base {
	private String name;
	@Column(nullable = false)
	private String dni;
	private String gender;
	private int age;
	private String address;
	private String phone;
}
