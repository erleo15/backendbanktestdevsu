package com.devsu.hackerearth.backend.client.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;

@RestController
@RequestMapping("/api/clients")
public class ClientController {

	private final ClientService clientService;

	public ClientController(ClientService clientService) {
		this.clientService = clientService;
	}

	@GetMapping
	public ResponseEntity<List<ClientDto>> getAll() {
		// api/clients
		// Get all clients
		return ResponseEntity.ok(clientService.getAll());//retorna si encontro o no
	}

	@GetMapping("/{id}")
	public ResponseEntity<ClientDto> get(@PathVariable Long id) {
		// api/clients/{id}
		// Get clients by id
		ClientDto clientDto = clientService.getById(id);
		if(clientDto == null){
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(clientDto);
	}

	@PostMapping
	public ResponseEntity<ClientDto> create(@Valid @RequestBody ClientDto clientDto) {
		// api/clients
		// Create client
		ClientDto clientNew = clientService.create(clientDto);
		return ResponseEntity.status(HttpStatus.CREATED).header("Location", "/api/clients/"+clientNew.getId()).body(clientNew);
	}

	@PutMapping("/{id}")
	public ResponseEntity<ClientDto> update(@PathVariable Long id, @RequestBody ClientDto clientDto) {
		// api/clients/{id}
		// Update client
		ClientDto clientDtoResult = clientService.getById(id);
		if(clientDtoResult == null){
			return ResponseEntity.notFound().build();
		}
		clientDto.setId(id);
		ClientDto updateResult = clientService.update(clientDto);
		if(updateResult == null){
			return ResponseEntity.ok(clientDto);
		}
		return ResponseEntity.ok(updateResult);
	}

	@PatchMapping("/{id}")
	public ResponseEntity<ClientDto> partialUpdate(@PathVariable Long id,
			@RequestBody PartialClientDto partialClientDto) {
		// api/accounts/{id}
		// Partial update accounts
		ClientDto clientDtoUpdated = clientService.partialUpdate(id, partialClientDto);
		if(clientDtoUpdated == null){
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(clientDtoUpdated);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		// api/clients/{id}
		// Delete client
		ClientDto clientDto = clientService.getById(id);
		if(clientDto == null){
			return ResponseEntity.notFound().build();
		}
		clientService.deleteById(id);
		return ResponseEntity.noContent().build();
	}
}
