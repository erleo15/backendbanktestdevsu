package com.devsu.hackerearth.backend.client.exception;

public class DuplicatedDniException extends RuntimeException{
    public DuplicatedDniException(String dni){
        super("Dni is present: " + dni);
    }
}
