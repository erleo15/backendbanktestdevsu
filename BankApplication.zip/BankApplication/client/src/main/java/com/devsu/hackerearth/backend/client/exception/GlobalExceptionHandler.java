package com.devsu.hackerearth.backend.client.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ClientNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleClientNotFound(ClientNotFoundException clientNotFoundException) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
        .body(new ErrorResponse().setStatus(HttpStatus.NOT_FOUND).setMessage(clientNotFoundException.getMessage()));
    }

    @ExceptionHandler(DuplicatedDniException.class)
    public ResponseEntity<ErrorResponse> handleDuplicatedDni(DuplicatedDniException duplicatedDniException){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
        .body(new ErrorResponse().setStatus(HttpStatus.BAD_REQUEST).setMessage(duplicatedDniException.getMessage()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationFields(MethodArgumentNotValidException methodArgumentNotValidException){
        Map<String, Object> validationErrors = new HashMap<>();
        methodArgumentNotValidException.getBindingResult().getFieldErrors()
        .stream().forEach(currentError->{
            validationErrors.put(currentError.getField(), currentError.getDefaultMessage());
        });
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(validationErrors);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericError(Exception e){
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
        .body(new ErrorResponse().setMessage(e.getMessage()).setStatus(HttpStatus.INTERNAL_SERVER_ERROR));
    }
}
