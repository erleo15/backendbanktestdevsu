package com.devsu.hackerearth.backend.client.interceptor;


import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.jboss.logging.Logger;
import org.springframework.web.servlet.HandlerInterceptor;

import lombok.SneakyThrows;

public class LoggingInterceptor implements HandlerInterceptor{
    private static final Logger logger = LoggerFactory.logger(LoggingInterceptor.class);

    @Override
    @SneakyThrows
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler){
        String uuid = UUID.randomUUID().toString();
        String staticUUID = "4db5cefd-3897-4db6-9ee8-1c7a7b01416e";
        logger.info(staticUUID + "-> START log with UUID: " + uuid);
        logger.info(staticUUID + "->RequesURL: " + request.getRequestURL());
        logger.info(staticUUID + "-> RequestParams: " + request.getQueryString());
        return true;
    }
}
