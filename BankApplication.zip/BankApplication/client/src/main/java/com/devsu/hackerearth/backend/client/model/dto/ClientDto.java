package com.devsu.hackerearth.backend.client.model.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.devsu.hackerearth.backend.client.model.Client;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@Accessors(chain=true)
public class ClientDto {

	private Long id;
	
	@NotBlank
	@NotNull
	private String dni;
	
	@NotNull
	@NotBlank
	private String name;
	
	@NotNull
	@NotBlank
	private String password;
	
	@NotNull
	@NotBlank
	private String gender;
	
	@Min(value = 0)
	@Max(value = 100)
	private int age;

	private String address;
	
	private String phone;
	private boolean isActive;

	public ClientDto(Client client){
		this.id = client.getId();
		this.dni = client.getDni();
		this.name = client.getName();
		this.password = client.getPassword();
		this.gender = client.getGender();
		this.age = client.getAge();
		this.address = client.getAddress();
		this.phone = client.getPhone();
		this.isActive = client.isActive();
	}
}
