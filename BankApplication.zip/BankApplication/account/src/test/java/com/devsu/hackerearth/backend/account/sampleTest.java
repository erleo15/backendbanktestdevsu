package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

import org.jboss.logging.Logger;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.devsu.hackerearth.backend.account.controller.AccountController;
import com.devsu.hackerearth.backend.account.controller.TransactionController;
import com.devsu.hackerearth.backend.account.exception.AccountNotFoundException;
import com.devsu.hackerearth.backend.account.exception.TransactionNotFoundException;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.service.AccountService;
import com.devsu.hackerearth.backend.account.service.TransactionService;

import org.springframework.http.HttpHeaders;

import lombok.SneakyThrows;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
public class sampleTest {

	private final Logger log = Logger.getLogger(getClass());
	private AccountService accountService = mock(AccountService.class);
	private AccountController accountController = new AccountController(accountService);
	private TransactionService transactionService = mock(TransactionService.class);
	private TransactionController transactionController = new TransactionController(transactionService);
	// For IT TEST
	@Autowired
	private TestRestTemplate restTemplate;
	@Value("${ms.client.find.by.id.endpoint}")
	private String endpoint;

	@Test
	void createAccountTest() {
		// Arrange
		AccountDto newAccount = new AccountDto(1L, "number", "savings", 0.0, true, 1L);
		AccountDto createdAccount = new AccountDto(1L, "number", "savings", 0.0, true, 1L);
		when(accountService.create(newAccount)).thenReturn(createdAccount);

		// Act
		ResponseEntity<AccountDto> response = accountController.create(newAccount);

		// Assert
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertEquals(createdAccount, response.getBody());
	}

	@Test
	void testGetAccountByIdNotFound() {
		try {
			ResponseEntity<AccountDto> responseEntity = accountController.get(9L);
			assertEquals(responseEntity.getBody(), null);
		} catch (Exception e) {
			assertTrue(e instanceof AccountNotFoundException);
			assertEquals("Account not found. Id:" + 9L, e.getMessage());
		}
	}

	@Test
	void testGetTransactionByIdNotFound() {
		try {
			ResponseEntity<TransactionDto> responseEntity = transactionController.get(22L);
			assertEquals(responseEntity.getBody(), null);
		} catch (Exception e) {
			assertTrue(e instanceof TransactionNotFoundException);
			assertEquals("Transaction not found. Id: " + 9L, e.getMessage());
		}
	}

	// IT TEST
	@Test
	@SneakyThrows
	void createClientAccountTest() {

		Long clientId = 100L;
		String endpointCreate = endpoint.replace("/{id}", "");

		log.info("Endpoint in unittest: " + endpointCreate);

		ClientDto clientDtoNew = new ClientDto(clientId, "1234567890", "Jhon Deer", "pas.2345", "M", 36,
				"Dir str new brand 01", "0982345678", false);
		HttpHeaders headersRequest = new HttpHeaders();
		headersRequest.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<ClientDto> requestClientCreated = new HttpEntity<>(clientDtoNew, headersRequest);
		System.out.println(endpointCreate+"############");
		ResponseEntity<ClientDto> responseEntity = restTemplate.postForEntity(endpointCreate, requestClientCreated, ClientDto.class);

		assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());

		ClientDto clientCreated = responseEntity.getBody();

		AccountDto account = new AccountDto(null, "AHO001", "savings", 20.15, true, clientCreated.getId());
		HttpEntity<AccountDto> reqEntity = new HttpEntity<>(account);

		ResponseEntity<AccountDto> responseAccount = restTemplate.postForEntity("http://localhost:8000/api/accounts", reqEntity,
				AccountDto.class);
		 //assertEquals(HttpStatus.CREATED, responseAccount.getStatusCode());
		 //assertEquals("AHO001", responseAccount.getBody().getNumber());
	}
}
