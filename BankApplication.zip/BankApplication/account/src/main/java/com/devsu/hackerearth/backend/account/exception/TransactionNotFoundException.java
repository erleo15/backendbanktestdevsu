package com.devsu.hackerearth.backend.account.exception;

public class TransactionNotFoundException extends RuntimeException {
    public TransactionNotFoundException(Long id) {
        super("Transaction not found. Id: " + id);
    }
}
