package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.exception.AccountNotFoundException;
import com.devsu.hackerearth.backend.account.exception.InsufficientBalanceException;
import com.devsu.hackerearth.backend.account.exception.TransactionNotFoundException;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

import lombok.SneakyThrows;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountService accountService;

    public TransactionServiceImpl(TransactionRepository transactionRepository, AccountService accountService) {
        this.transactionRepository = transactionRepository;
        this.accountService = accountService;
    }

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions
        return transactionRepository.findAll()
                .stream()
                .map(this::transaction2TransactionDto)
                .collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
        Transaction transaction = transactionRepository.findById(id).orElseThrow(
                () -> new TransactionNotFoundException(id));
        return transaction2TransactionDto(transaction);
    }

    @Override
    @SneakyThrows
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
        AccountDto accountDto = accountService.getById(transactionDto.getAccountId());
        if(!accountDto.isActive()){
            throw new AccountNotFoundException(accountDto.getId());
        }

        Transaction lastTrn = transactionRepository.findTopByAccountIdOrderByDateDesc(accountDto.getId())
        .orElse(null);

        double lastBalance = (lastTrn != null) ? lastTrn.getBalance() : accountDto.getInitialAmount();

        double newBalanceTrn= validateBalance(transactionDto, lastBalance);

        Transaction transactionToSave = new Transaction().setAccountId(transactionDto.getAccountId())
                                  .setAmount(transactionDto.getAmount())
                                  .setDate(new Date())
                                  .setType(transactionDto.getType())
                                  .setBalance(newBalanceTrn);
        Transaction savedTransaction = transactionRepository.save(transactionToSave);
		return this.transaction2TransactionDto(savedTransaction);
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        // Report
        List<AccountDto> accounts = accountService.getAllByClientId(clientId);

        List<Long> accountsIds = accounts.stream().map(AccountDto::getId).collect(Collectors.toList());
        List<Transaction> transactions = transactionRepository.findByAccountIdInAndDateBetween(accountsIds,
                dateTransactionStart, dateTransactionEnd);

        List<BankStatementDto> report = new ArrayList<>();

        for (Transaction transaction : transactions) {
            AccountDto accountToReport = accounts.stream()
                    .filter(currentAccount -> currentAccount.getId().equals(transaction.getAccountId()))
                    .findFirst().orElse(null);
            if (accountToReport != null) {
                report.add(
                        new BankStatementDto(
                                transaction.getDate(),
                                clientId.toString(), // implementar el recuperado de nombre
                                accountToReport.getNumber(),
                                accountToReport.getType(),
                                accountToReport.getInitialAmount(),
                                accountToReport.isActive(),
                                transaction.getType(),
                                transaction.getAmount(),
                                transaction.getBalance()));
            }
        }
        return report;
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
        Optional<Transaction> lastTrn = transactionRepository.findTopByAccountIdOrderByDateDesc(accountId);
        return lastTrn.map(this::transaction2TransactionDto).orElse(null);
    }

    private TransactionDto transaction2TransactionDto(Transaction transaction) {
        return new TransactionDto(transaction.getId(),
                transaction.getDate(),
                transaction.getType(), transaction.getAmount(), transaction.getBalance(), transaction.getAccountId());
    }

    private Transaction transactionDto2Transaction(TransactionDto transactionDto) {
        Transaction transaction = new Transaction().setAccountId(transactionDto.getAccountId())
                .setAmount(transactionDto.getAmount())
                .setBalance(transactionDto.getBalance())
                .setDate(transactionDto.getDate())
                .setType(transactionDto.getType());
        transaction.setId(transactionDto.getId());
        return transaction;
    }

    public double validateBalance(TransactionDto transactionDto, double lastBalance) {
        double result = 0.0;
        double amount = transactionDto.getAmount();//Math.abs(transactionDto.getAmount());
        switch (transactionDto.getType().toUpperCase()) {
            case "DEBIT":
                if (lastBalance < amount) {
                    throw new InsufficientBalanceException(transactionDto.getAccountId(), lastBalance);
                }
                result = lastBalance - amount;
                break;
            case "CREDIT":
                result = lastBalance + amount;
                break;
            default:
                throw new RuntimeException("The type of transaction is invalid. Type:" + transactionDto.getType());
        }
        return result;
    }
}
