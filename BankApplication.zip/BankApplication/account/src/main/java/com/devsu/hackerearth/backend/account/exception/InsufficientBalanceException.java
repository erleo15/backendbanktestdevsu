package com.devsu.hackerearth.backend.account.exception;

public class InsufficientBalanceException extends RuntimeException {
    public InsufficientBalanceException(Long accountId, double balance) {
        super("Saldo Insuficiente. Cuenta:" + accountId + ", saldo: " + balance);
    }
}
