package com.devsu.hackerearth.backend.account.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleClientNotFound(AccountNotFoundException accountNotFoundException) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new ErrorResponse().setStatus(HttpStatus.NOT_FOUND)
                        .setMessage(accountNotFoundException.getMessage()));
    }

    @ExceptionHandler(TransactionNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleTransactionNotFound(TransactionNotFoundException transactionNotException) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(new ErrorResponse().setStatus(HttpStatus.NOT_FOUND)
                        .setMessage(transactionNotException.getMessage()));
    }

    @ExceptionHandler(InsufficientBalanceException.class)
    public ResponseEntity<ErrorResponse> handleInsufficientBalance(InsufficientBalanceException insufficientBalanceException) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorResponse().setStatus(HttpStatus.NOT_FOUND)
                        .setMessage(insufficientBalanceException.getMessage()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationFields(
            MethodArgumentNotValidException methodArgumentNotValidException) {
        Map<String, Object> validationErrors = new HashMap<>();
        methodArgumentNotValidException.getBindingResult().getFieldErrors()
                .stream().forEach(currentError -> {
                    validationErrors.put(currentError.getField(), currentError.getDefaultMessage());
                });
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(validationErrors);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericError(Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorResponse().setMessage(e.getMessage()).setStatus(HttpStatus.INTERNAL_SERVER_ERROR));
    }
}
