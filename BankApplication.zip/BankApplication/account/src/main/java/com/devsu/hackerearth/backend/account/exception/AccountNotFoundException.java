package com.devsu.hackerearth.backend.account.exception;

public class AccountNotFoundException extends RuntimeException {
    public AccountNotFoundException(Long id) {
        super("Account not found. Id:" + id);
    }
}
