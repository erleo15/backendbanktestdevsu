package com.devsu.hackerearth.backend.account.client;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.devsu.hackerearth.backend.account.model.dto.ClientDto;

import lombok.SneakyThrows;

@Component
public class ClientRestService {

    private final Logger log = Logger.getLogger(this.getClass());
    private final RestTemplate restTemplate;

    @Value("${ms.client.find.by.id.endpoint}")
    private String endpoint;

    public ClientRestService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @SneakyThrows
    public ClientDto getClientById(Long clientId){
        log.info(String.format("Rest endpoint:%s - IdClient: %d", endpoint.toString(), clientId));
        return restTemplate.getForObject(endpoint, ClientDto.class, clientId);
    }
}
