package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.client.ClientRestService;
import com.devsu.hackerearth.backend.account.exception.AccountNotFoundException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final ClientRestService clientRestService;

    public AccountServiceImpl(AccountRepository accountRepository, ClientRestService clientRestService) {
        this.accountRepository = accountRepository;
        this.clientRestService = clientRestService;
    }

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
        return accountRepository.findByIsActiveTrue().stream()
                .map(this::accountToDto).collect(Collectors.toList());
    }

    @Override
    public List<AccountDto> getAllByClientId(Long clientId) {
        // Get Accounts by clientId
        return accountRepository.findByClientIdAndIsActiveTrue(clientId).orElseThrow(
                () -> new RuntimeException("No active accounts for client. IdClient:" + clientId)).stream()
                .map(this::accountToDto).collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
        Account account = accountRepository.findByIdAndIsActiveTrue(id).orElseThrow(
                () -> new AccountNotFoundException( id));
        return this.accountToDto(account);
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account
        ClientDto clientDto = clientRestService.getClientById(accountDto.getClientId());
        if(clientDto==null){
            throw new RuntimeException("Cliente no existe");
        }
        if (accountDto.isActive() && accountRepository.existsByNumberAndIsActiveTrue(accountDto.getNumber())) {
            throw new RuntimeException("Account already existsand active. Account:" + accountDto.getNumber());
        }
        Account account = accountDtoToAccount(accountDto);
        return accountToDto(accountRepository.save(account));
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        // Update account
        Account account = this.getByIdAll(accountDto.getId());
        if (account.isActive() &&
                (account.getNumber().compareTo(accountDto.getNumber()) != 0
                        || account.isActive() != accountDto.isActive())) {
            if (accountRepository.existsByNumberAndIsActiveTrue(accountDto.getNumber())) {
                throw new RuntimeException("Account already exists and active. Id" + accountDto.getId() + ", Number:"
                        + accountDto.getNumber());
            }
        }
        account.setNumber(accountDto.getNumber())
                .setType(accountDto.getType())
                .setInitialAmount(accountDto.getInitialAmount())
                .setActive(accountDto.isActive())
                .setClientId(accountDto.getClientId());
        Account accountUpdated = accountRepository.save(account);
        return accountToDto(accountUpdated);
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        Account account = this.getByIdAll(id);
        if (partialAccountDto.isActive() != account.isActive()) {
            if (partialAccountDto.isActive()) {
                if (accountRepository.existsByNumberAndIsActiveTrue(account.getNumber())) {
                    throw new RuntimeException("Account already exists and active. Id" + account.getId() + ", Number:"
                            + account.getNumber());
                }
            }
            account.setActive(partialAccountDto.isActive());
        }
        Account updatedAccount = accountRepository.save(account);
        return accountToDto(updatedAccount);
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        Account account = this.getByIdAll(id);
        account.setActive(false);
        accountRepository.save(account);
    }

    private AccountDto accountToDto(Account account) {
        return new AccountDto(account.getId(), account.getNumber(), account.getType(), account.getInitialAmount(),
                account.isActive(), account.getClientId());
    }

    private Account accountDtoToAccount(AccountDto accountDto) {
        return new Account().setActive(accountDto.isActive()).setClientId(accountDto.getClientId())
                .setInitialAmount(accountDto.getInitialAmount()).setNumber(accountDto.getNumber())
                .setType(accountDto.getType());
    }

    private Account getByIdAll(Long id) {
        return accountRepository.findByIdAndIsActiveTrue(id).orElseThrow(
                () -> new AccountNotFoundException(id));
    }
}
